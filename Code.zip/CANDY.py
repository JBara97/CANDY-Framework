import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
import collections
from tqdm import trange
import seaborn as sns
import pandas as pd

def payoff(g,b=100,c=50):
    """ payoff takes in a network g and returns the payoff for all nodes, playing the Prisoner's Dilemma with benefit b and cost c. Output is an numpy.ndarray of size N. """

    payoff = np.array(list(nx.get_node_attributes(g,'C').values()))
    payoff = -c*payoff*np.array([d for n,d in g.degree()]) # any cooperators lose
    for n in g:
        neighbors = g.neighbors(n)
        for m in neighbors:
            if g.nodes[m]['C']:
                payoff[n] += b
    return payoff

def payoff_n(g,n):
    """ same as payoff but for a single node n"""
    pay = 0
    if g.nodes[n]['C']:
        pay = -50*len(g.neighbors(n))
    for m in g.neighbors(n):
        if g.nodes[m]['C']:
            pay += 100
    return pay

def cooperator_rate(g):
    atts = list(nx.get_node_attributes(g,'C').values())
    return len([a for a in atts if a==1])/len(g)

# ------------------ STRATEGY UPDATE ----------------------
def imitate_payoff(g,eta,**kwargs): #BM1
    """
    imitate_payoff strategy update:
    eta is a number of edges
    imitate the strategy of j only if pi[j] > pi[i]
    """
    e_list = [list(g.edges())[i] for i in
              np.random.choice(len(g.edges()),size=min(eta,len(g.edges())),replace=False)]
    payoffs = payoff(g)
    first = np.random.randint(2,size=eta)
    strat_dict = {e[first[i]]:g.nodes[e[1-first[i]]]['C'] for i,e in enumerate(e_list)
                  if payoffs[e[1-first[i]]]>payoffs[e[first[i]]]}
    nx.set_node_attributes(g,strat_dict,'C')
    return g

def voter_model(g,eta,**kwargs): #BM2
    """
    voter_model strategy update:
    eta is the number of nodes
    imitate the strategy of j only if the fraction of non-similar neighbours exceeds a threshold
	if i cooperator: i defects iff defecting neighbourhood fraction > v_cd
	if i defector: i cooperates iff cooperative neighbourhood fraction > v_dc
    """
    v=kwargs['v']
    for i in np.random.choice(g,size=eta):
        neigh=list(g.neighbors(i))
        sigma = g.nodes[i]['C']
        if len(neigh) > 0:
            delta = len([j for j in neigh if g.nodes[j]['C']==sigma])/len(neigh)
            if 1-delta > v[sigma]:
                nx.set_node_attributes(g,{i:1-sigma},'C')
    return g

def pairwise_comparison(g,eta,**kwargs):
    """
    pairwise_comparison strategy update:
    eta is the number of nodes
    beta temperature parameter"""
    beta = kwargs['beta']
    def sigmoid(p_i,p_j):
        return 1/(1+np.exp(beta*(float(p_j-p_i))))
    for i in np.random.choice(g,size=eta):
        sigma = g.nodes[i]['C']
        neighs = list(g.neighbors(i))
        if len(neighs)>0:
            payoffs=payoff(g)
            neighbours = {node:[g.nodes[node]['C'],sigmoid(payoffs[i],payoffs[node])] for node in neighs}
            p_i = np.mean([neighbours[node][1] for node in neighs if neighbours[node][0]!=sigma])
            if np.random.rand()<p_i:
                nx.set_node_attributes(g,{i:1-sigma},'C')
    return g

# ------------------ GRAPHICAL UPDATE ----------------------
def extreme_popularity(g,**kwargs):
    """
    extreme_popularity graphical update:
    cooperative alters are always attached to,
    defective alters always disconnected to
    """
    n,m = np.random.choice(g,size=2,replace=False)
    if g.nodes[m]['C']:
        g.add_edge(n,m)
    elif g.has_edge(n,m):
        g.remove_edge(n,m)
    return g

def preferential_attachment_c(g,**kwargs):
    """
    preferential_attachment_c graphical update:
    alters j are (dis)connected to with some probability p_j
    for defectors: p_i \propto 1 prob to disconnect
    cooperators: p_j \propto k_j prob to connect
    """
    n = np.random.choice(g)
    weighted_node_list = [m for m in g if (1-g.nodes[m]['C'])]
    for m,d in g.degree():
        if (g.nodes[m]['C']):
            weighted_node_list += [m]*d
    m = np.random.choice(list(filter((n).__ne__, weighted_node_list)))
    if g.nodes[m]['C']:
        g.add_edge(n,m)
    elif g.has_edge(n,m):
        g.remove_edge(n,m)
    return g

def exogenously_imposed(g,**kwargs):
    return kwargs['next_graph']

# ------------------ EVOLUTION -----------------------------
def evolve(g,T,graph=False,cooperator=False,
    zeta=0,eta=1,
    strat_step=imitate_payoff,tie_step=extreme_popularity,
    **kwargs):
    """ For a graph g undergoing a coevolutionary process in time [0,T], evolve outputs:
		- [default] payoff of all nodes, OR
		- [cooperator] payoff and cooperator frequency, OR
		- [graph] graph at all time steps

	    Strategy updates (once every zeta timesteps):
	    	- [1] randomly choose eta EDGES; i imitates j iff p_j > p_i
	    	- [2] randomly choose eta NODES;
			if i cooperator: i defects iff defecting neighbourhood fraction > v_cd
			if i defector: i cooperates iff cooperative neighbourhood fraction > v_dc
		- [3] randomly choose eta NODES; i imitates j probabilistically with probability that follows a sigmoid

	    Tie updates (once per timestep):
	    	- [1] randomly choose (i,j):
	    		if j is a cooperator, connect
	    		if j is a defector, disconnect
	    	- [2] randomly choose a node n and another node m with probability:
	    		k_m 	if m is a cooperator
	    		1 	if m is a defector

    """
    # -------------- KWARGS ----------------------
    if 'v' not in kwargs:
        kwargs['v'] = {1:0.5,0:0.8}
    if 'beta' not in kwargs:
        kwargs['beta'] = 1

    # ~~~~~~~~~~~~~RUNNING ROUNDS~~~~~~~~~~~~~~~~~~~~~~~~
    if zeta == 0:
        zeta = T+1
    if graph:
        G = [0]*(T+1)
        G[0] = g.copy()
        for t in range(1,T+1):
            if int(t%zeta)==0:
                g=strat_step(g,eta,**kwargs)
            g=tie_step(g,**kwargs)
            G[t] = g.copy()
        return G
    elif cooperator:
        payoffs = np.zeros((len(g),T+1))
        payoffs[:,0] = payoff(g)
        if cooperator:
            cooperator_t = np.zeros(T+1)
            cooperator_t[0] = cooperator_rate(g)
            for t in range(1,T+1):
                if int(t%zeta)==0:
                    g=strat_step(g,eta,**kwargs)
                g=tie_step(g,**kwargs)
                payoffs[:,t] = payoff(g)
                cooperator_t[t] = cooperator_rate(g)
            return payoffs,cooperator_t
    else:
        payoffs = np.zeros((len(g),T+1))
        payoffs[:,0] = payoff(g)
        for t in range(1,T+1):
            if int(t%zeta)==0:
                g=strat_step(g,eta,**kwargs)
            g=tie_step(g,**kwargs)
            payoffs[:,t] = payoff(g)
        return payoffs


# --------------- UTILITY -----------------------
def energy_level(C,N):
    return 25*C*(C+N-2)/N

#def energy_evolution(C,N,T,x0,y0):
#    chi = C*(C-1) + C*(N-C)/2
#    return 50*(chi-(chi-2*x0-y0)*np.exp(-2*np.arange(T+1)/(N*(N-1))))/N

def measure_xy(g):
    x=0
    y=0
    for u,v in list(g.edges()):
        if g.nodes[u]['C']&g.nodes[v]['C']:
            x+=1
        elif g.nodes[u]['C']|g.nodes[v]['C']:
            y+=1
    return x,y

# ~~~~~~~~~~~~~~~~ HELPERS FOR QUICK GRAPH GENERATION
def BA(N,C,rand=True,m=3):
    g = nx.generators.random_graphs.barabasi_albert_graph(N,3)
    if rand:
        cooperate = np.random.choice(range(N),size=C,replace=False)
    else:
        cooperate = np.array([d for n,d in g.degree()]).argsort()[-C:][::-1]
    nx.set_node_attributes(g,{n:int(n in cooperate) for n in range(N)},'C')
    return g

def ER(N,C,p=0.2):
    g = nx.gnp_random_graph(N,p)
    cooperate = range(C)#np.random.choice(range(N),size=C,replace=False)
    nx.set_node_attributes(g,{n:int(n in cooperate) for n in range(N)},'C')
    return g

def CClique(N,C):
    g = nx.complete_graph(C)
    g.add_nodes_from(range(C,N))
    nx.set_node_attributes(g,{n:int(n<C) for n in range(N)},'C')
    return g

def Complete(N,C):
    g = nx.complete_graph(N)
    nx.set_node_attributes(g,{n:int(n<C) for n in range(N)},'C')
    return g

def SBM(N,C):
    # for ease the SBM parameters are fixed here
    g = nx.stochastic_block_model([10,10],[[0.8,0.05],[0.05,0.8]])
    cooperate = np.random.choice(range(N),size=C,replace=False)
    nx.set_node_attributes(g,{n:int(n in cooperate) for n in range(N)},'C')
    return g
